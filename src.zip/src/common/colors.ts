export default{
    primaryUser: "#DD2803",
    secondaryUser: "F4D147",
    primaryAdmin: "840705",
    secondaryAdmin: "660605",
    lightYellow: "#D9D9D9",
    beige: '#F9F2EA',
    lightGray: 'F3F3F3'
}