import React from 'react'
import '../about/userAccProfile.css';
import { FaRegUserCircle } from "react-icons/fa";
import { MdOutlineLogout } from "react-icons/md";

function UserProfilePage(){ 
    return(
        <div className = "h-[100vh] bg-[#F9F2EA]">

            <div className="mx-auto w-[90vw] border-b-[1px] border-black">
                <p className="pt-10 text-[30pt] font-[Poppins] font-bold">User Information</p>
                <p className="text-[#929090] text-[15pt] font-[Poppins] font-bold">Protect and Secure Your Account</p>
            </div>

            <div className="m-auto h-[80vh] w-[90vw] mt-7 mb-10 mr-[-5] rounded-3xl bg-white">

                <div>

                    <div className="float-left border-r-[1pt] border-black mt-[5vh]">
                        <FaRegUserCircle className="text-[23vh] mx-[15vh] mt-[6vh]"/>
                        <br />
                        <h1 className="userName">Kathea Mari</h1>
                        <br />
                        <br />
                        <br />
                        <table>
                            <tr className="row">
                                <td className="var">Gender:</td>
                                <td className="value">Female</td>
                            </tr>
                            <tr className="row">
                                <td className="var">Address:</td>
                                <td className="value">123 Sesasmi Street st. , neverland peter pan amazon Cebu City</td>
                            </tr>
                            <tr className="row">
                                <td className="var">BirthDate:</td>
                                <td className="value">September 20, 2000</td>
                            </tr>
                            <tr className="row">
                                <td className="var">Age:</td>
                                <td className="value">23</td>
                            </tr>
                            <tr className="row">
                                <td className="var">Email:</td>
                                <td className="value">Example@example.com</td>
                            </tr>
                            <tr className="row">
                                <td className="var">Phone Number:</td>
                                <td className="value">0937 462 5364</td>
                            </tr>
                        </table>

                        <button className="h-[15pt] mx-[3cm] mt-[1cm]"><MdOutlineLogout/>Logout</button>
                    </div>
                
                    <div className="">
                    <h1 className="resTitle">Reservation History</h1>
                        <div className="float-right h-[40vh] w-[55vw] m-auto rounded-3xl bg-red">
                            <tr className="resRow">
                                <td className="col">Date</td>
                                <td className="col">Time</td>
                                <td className="col">Organizer</td>
                                <td className="col">Event Size</td>
                                <td className="col">Status</td>
                            </tr>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    )
    
}

export default UserProfilePage