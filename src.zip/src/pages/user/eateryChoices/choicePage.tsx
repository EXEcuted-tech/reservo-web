import React from 'react'
import colors from '../../../common/colors'

const ChoicePage = () => {
  return (
    <div className={`bg-[#F9F2EA] h-[80vh]`}>
        choicePage
    </div>
  )
}

export default ChoicePage